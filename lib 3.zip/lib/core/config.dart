// Centralized API base URL. Set via --dart-define=API_BASE when needed.
// Default points to the current local network host machine.
const String apiBase = String.fromEnvironment(
  'API_BASE',
  defaultValue: 'http://172.19.70.85:5000',
);

// Fallback for Android emulators that map host to 10.0.2.2
const String apiEmulatorFallback = 'http://10.0.2.2:5000';
